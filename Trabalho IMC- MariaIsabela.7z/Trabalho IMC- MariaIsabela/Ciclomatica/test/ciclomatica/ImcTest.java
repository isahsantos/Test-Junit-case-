/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ciclomatica;

import junit.framework.TestCase;
import ciclomatica.Imc;
import ciclomatica.CountImc;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Isabela
 */
public class ImcTest extends TestCase {
    
      Imc imc;

    @Override
	protected void setUp() throws Exception {
		super.setUp();
		imc = new Imc();
	}
	public void testCalcularImc_MulherAbaixoPeso() {
		imc.setSexo("F");
		imc.setAltura(1);
		imc.setPeso(17);
		assertEquals("Abaixo do peso", CountImc.countImc(imc));
	}
    public void testCalcularImc_MulherPesoNormal() {
		imc.setSexo("F");
		imc.setAltura(1);
		imc.setPeso(19.5);
		assertEquals("No peso normal", CountImc.countImc(imc));
	}

	public void testCalcularImc_MulherMargAcimaPeso() {
		imc.setSexo("F");
		imc.setAltura(1);
		imc.setPeso(26.0);
		assertEquals("Marginalmente acima do peso", CountImc.countImc(imc));
	}

	public void testCalcularImc_MulherAcimaPeso() {
		imc.setSexo("F");
		imc.setAltura(1);
		imc.setPeso(27.8);
		assertEquals("Acima do peso ideal", CountImc.countImc(imc));
	}

	public void testCalcularImc_MulherObeso() {
		imc.setSexo("F");
		imc.setAltura(1);
		imc.setPeso(40);
		assertEquals("Obeso", CountImc.countImc(imc));
    }
    public void testCountImc_HomemAbaixoPeso() {
		imc.setSexo("M");
		imc.setAltura(1);
		imc.setPeso(20);
		assertEquals("Abaixo do peso", CountImc.countImc(imc));
	}

	public void testCalcularImc_HomemPesoNormal() {
		imc.setSexo("M");
		imc.setAltura(1);
		imc.setPeso(20.9);
		assertEquals("No peso normal", CountImc.countImc(imc));
	}

	public void testCalcularImc_HomemMargAcimaPeso() {
		imc.setSexo("M");
		imc.setAltura(1);
		imc.setPeso(27.0);
		assertEquals("Marginalmente acima do peso", CountImc.countImc(imc));
	}

	public void testCalcularImc_HomemAcimaPeso() {
		imc.setSexo("M");
		imc.setAltura(1);
		imc.setPeso(27.9);
		assertEquals("Acima do peso ideal", CountImc.countImc(imc));
	}

	public void testCalcularImc_HomemObeso() {
		imc.setSexo("M");
		imc.setAltura(1);
		imc.setPeso(33);
		assertEquals("Obeso", CountImc.countImc(imc));
	}



	
}
