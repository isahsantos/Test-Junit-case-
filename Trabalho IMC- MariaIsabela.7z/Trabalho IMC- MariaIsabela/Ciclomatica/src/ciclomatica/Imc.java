/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ciclomatica;

/**
 *
 * @author Isabela
 */
public class Imc implements interfaceCiclomatica {
    private String sexo;
    private double peso;
    private double altura;

    public Imc() {}

    
    public String getSexo() {
        return sexo;
    }

    
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

   
    public double getPeso() {
        return peso;
    }

  
    public void setPeso(double peso) {
        this.peso = peso;
    }

   
    public double getAltura() {
        return altura;
    }

    
    public void setAltura(double altura) {
        this.altura = altura;
    }
}
